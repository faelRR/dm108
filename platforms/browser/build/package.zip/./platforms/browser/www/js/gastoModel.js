function Gasto( descricao, data , valor) {
    this.id = 0;
    this.data = data;
    this.descricao = descricao;
    this.valor = valor;
}